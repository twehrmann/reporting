pkgname <- "dCarbono"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('dCarbono')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("ER")
### * ER

flush(stderr()); flush(stdout())

### Name: Cambios
### Title: Cambios en almacenes de carbono
### Aliases: Cambios

### ** Examples


## Not run: 
##D 
##D #rm(list=ls())
##D #rm(list=ls())
##D library(dCarbono)
##D 
##D ###############################################################################
##D ##############################Se lee la base###################################
##D BaseT1<-read.csv(system.file("extdata/Calculo_20140421_CarbonoSitio(2004-2012)_VERSION_19_raices_CASO1y2_TOTALESt1.csv",package="dCarbono"))
##D BaseT1<-BaseT1[!(is.na(BaseT1$folio)),]
##D 
##D BaseT2<-read.csv(system.file("extdata/Calculo_20140421_CarbonoSitio(2004-2012)_VERSION_19_raices_CASO1y2_TOTALESt2.csv",package="dCarbono"))
##D BaseT2<-BaseT2[!(is.na(BaseT2$folio)),]
##D 
##D AreasEstratos<-read.csv(system.file("extdata/AreasEstratos.csv",package="dCarbono"))
##D 
##D EstratosBUR<-read.csv(system.file("extdata/1234_pmn45.csv",package="dCarbono"))
##D 
##D EstratosIPCC<-read.csv(system.file("extdata/EstratosPMN_IPCC.csv",package="dCarbono"))
##D 
##D ##############################Se crean bases de "T1" y "T2 sólo con las variables de interés"###################################
##D BaseT1dep<-data.frame(folio=BaseT1$folio, sitioT1=BaseT1$sitio, FechaT1=BaseT1$levantamiento_fecha_ejecucion,
##D 			    tipificacionT1=BaseT1$tipificacion, carbono_arbolesT1=BaseT1$carbono_arboles)
##D 
##D BaseT2dep<-data.frame(folio=BaseT2$folio, sitioT2=BaseT2$sitio, FechaT2=BaseT2$levantamiento_fecha_ejecucion,
##D 			    tipificacionT2=BaseT2$tipificacion, carbono_arbolesT2=BaseT2$carbono_arboles)
##D 
##D 
##D ##############################En cada base se cre una variable de "Conglomerado-Sito"###################################
##D BaseT1dep$CongSitioT1<-paste(as.character(BaseT1dep$folio),"-",as.character(BaseT1dep$sitioT1))
##D BaseT2dep$CongSitioT2<-paste(as.character(BaseT2dep$folio),"-",as.character(BaseT2dep$sitioT2))
##D 
##D ##################################Se unen las bases "BaseT1dep" y "BaseT2dep"#######################################
##D BaseT1T2<- merge(BaseT1dep, BaseT2dep, by.x = "CongSitioT1", by.y = "CongSitioT2",all=TRUE)
##D 
##D 
##D ###################Se identifica el estrato "del BUR" al que pertenece cada sitio en T1 y t2#######################
##D #Se seleccionan las variables de interés de la base de "Estratos"
##D EstratosBURdep<-data.frame(folio=EstratosBUR$NUMNAL, sitio=EstratosBUR$Sitio, EstratoSlV=EstratosBUR$clave_pmn4,
##D                 EstratoSV=EstratosBUR$clave_pmn5)
##D 
##D #En la base "EstratosBURdep" se crea una nueva variable de "Cong-Sitio"
##D EstratosBURdep$CongSitio<-paste(as.character(EstratosBURdep$folio),"-",as.character(EstratosBURdep$sitio))
##D 
##D #Se unen las bases "BaseT1T2" y "EstratosBURdep"
##D BaseT1T2<- merge(BaseT1T2, EstratosBURdep, by.x = "CongSitioT1", by.y = "CongSitio",all=TRUE)
##D 
##D 
##D ###################Se identifica el estrato "del IPCC" al que pertenece cada sitio en T1 y t2#######################
##D BaseT1T2<- merge(BaseT1T2, EstratosIPCC, by.x = "EstratoSlV", by.y = "pf_redd_clave_subcat_leno_pri_sec",all=TRUE)
##D 
##D 
##D #############################Se filtran los sitios reportados como "Iniciales" en T1 y T2############################
##D #se filtra todas las UMP cuya "tipificación" es "Inicial", "Reemplazo" o "Monitoreo" en T1
##D BaseT1T2=BaseT1T2[BaseT1T2$tipificacionT1=="Inicial" |
##D #              BaseT1T2$tipificacionT1=="Reemplazo" |
##D               BaseT1T2$tipificacionT1=="Monitoreo",]
##D 
##D #se filtra todas las USM cuya "tipificación" es "Inicial", "Reemplazo" o "Omitido-Remuestreo" en T2
##D BaseT1T2=BaseT1T2[BaseT1T2$tipificacionT2=="Inicial" |
##D #              BaseT1T2$tipificacionT2=="Reemplazo" |
##D               BaseT1T2$tipificacionT2=="Omitido-Remuestreo" & BaseT1T2$tipificacionT1=="Monitoreo" & BaseT1T2$pf_redd_ipcc_2003=="Praderas",]
##D 
##D 
##D ######################Se filtran las "Tierras Forestales" o "Praderas" definidas por el IPCC########################
##D BaseT1T2=BaseT1T2[BaseT1T2$pf_redd_ipcc_2003=="Tierras Forestales" | BaseT1T2$pf_redd_ipcc_2003=="Praderas",]
##D 
##D #############Se imputan los 0 en los conglomerdos reportados "Monitoreo" y que tenían "Pradera" en T1 y T2#########
##D BaseT1T2$CarbAerVivT1<-ifelse(BaseT1T2$tipificacionT1=="Monitoreo" & BaseT1T2$pf_redd_ipcc_2003=="Praderas",0,
##D        as.numeric(as.character(BaseT1T2$carbono_arbolesT1)))
##D 
##D BaseT1T2$CarbAerVivT2<-ifelse(BaseT1T2$tipificacionT1=="Monitoreo" & BaseT1T2$pf_redd_ipcc_2003=="Praderas"&
##D        BaseT1T2$tipificacionT2=="Omitido-Remuestreo",0, as.numeric(as.character(BaseT1T2$carbono_arbolesT2)))
##D 
##D ##############Se filtran los sitios que en T1 y/o en T2 contienen valores "NA" en el carbono estimado#############
##D #Se filtran todos los "NA" de la variable "CarbAerViv" en T1
##D BaseT1T2<-BaseT1T2[!(is.na(BaseT1T2$CarbAerVivT1)),]
##D 
##D #Se filtran todos los "NA" de la variable "CarbAerVivT2correg" en T2
##D BaseT1T2<-BaseT1T2[!(is.na(BaseT1T2$CarbAerVivT2)),]
##D 
##D ##############################Se filtran las transiciones de las zonas de permanencia###############################
##D #Se crea una variable de "Estratos de Transición"
##D BaseT1T2$EstTrnsT1T2<-paste(as.character(BaseT1T2$EstratoSlV),"-",as.character(BaseT1T2$EstratoSV))
##D 
##D #Se fltran los sitios que no son de permanencia
##D BaseT1T2=BaseT1T2[
##D BaseT1T2$EstTrnsT1T2=="ACUI - ACUI"  |
##D BaseT1T2$EstTrnsT1T2=="AGR - AGR"  |
##D BaseT1T2$EstTrnsT1T2=="AH - AH"  |
##D BaseT1T2$EstTrnsT1T2=="BC - BC"  |
##D BaseT1T2$EstTrnsT1T2=="BCO/P - BCO/P"  |
##D BaseT1T2$EstTrnsT1T2=="BCO/S - BCO/S"  |
##D BaseT1T2$EstTrnsT1T2=="BE/P - BE/P"  |
##D BaseT1T2$EstTrnsT1T2=="BE/S - BE/S"  |
##D BaseT1T2$EstTrnsT1T2=="BM/P - BM/P"  |
##D BaseT1T2$EstTrnsT1T2=="BM/S - BM/S"  |
##D BaseT1T2$EstTrnsT1T2=="EOTL/P - EOTL/P"  |
##D BaseT1T2$EstTrnsT1T2=="EOTL/S - EOTL/S"  |
##D BaseT1T2$EstTrnsT1T2=="EOTnL/P - EOTnL/P"  |
##D BaseT1T2$EstTrnsT1T2=="H2O - H2O"  |
##D BaseT1T2$EstTrnsT1T2=="MXL/P - MXL/P"  |
##D BaseT1T2$EstTrnsT1T2=="MXL/S - MXL/S"  |
##D BaseT1T2$EstTrnsT1T2=="MXnL/P - MXnL/P"  |
##D BaseT1T2$EstTrnsT1T2=="MXnL/S - MXnL/S"  |
##D BaseT1T2$EstTrnsT1T2=="OT - OT"  |
##D BaseT1T2$EstTrnsT1T2=="P - P"  |
##D BaseT1T2$EstTrnsT1T2=="SC/P - SC/P"  |
##D BaseT1T2$EstTrnsT1T2=="SC/S - SC/S"  |
##D BaseT1T2$EstTrnsT1T2=="SP/P - SP/P"  |
##D BaseT1T2$EstTrnsT1T2=="SP/S - SP/S"  |
##D BaseT1T2$EstTrnsT1T2=="SSC/P - SSC/P"  |
##D BaseT1T2$EstTrnsT1T2=="SSC/S - SSC/S"  |
##D BaseT1T2$EstTrnsT1T2=="VHL/P - VHL/P"  |
##D BaseT1T2$EstTrnsT1T2=="VHL/S - VHL/S"  |
##D BaseT1T2$EstTrnsT1T2=="VHnL/P - VHnL/P",]
##D 
##D #Se identifica el área de cada estrato
##D #Se identifica el Estrato
##D Estrato<-substr(x = AreasEstratos$Cves4_Cves5_pmn, 
##D                 start = 1, stop =as.integer(gregexpr("-",AreasEstratos$Cves4_Cves5_pmn))-2)
##D AreaHa<-AreasEstratos$AreasCves4_Cves5_pmn
##D 
##D AreasEstratos<-data.frame(Estrato,AreaHa)
##D 
##D #####################################Se imputa el área de muestreo a nivel de sitio################################
##D ai=rep(0.04,nrow(BaseT1T2))								  
##D 
##D t1=BaseT1T2$FechaT1
##D t2=BaseT1T2$FechaT2
##D conglomerado=BaseT1T2$folio.x
##D estrato=BaseT1T2$EstTrnsT1T2
##D y_t1=BaseT1T2$CarbAerVivT1
##D y_t2=BaseT1T2$CarbAerVivT2
##D 
##D rm(BaseT1T2)
##D 
##D out=Cambios(y_t1=y_t1, y_t2=y_t2, t1=t1, t2=t2, conglomerado=conglomerado, 
##D             estrato=estrato, ai=ai, AreasEstratos=AreasEstratos)
##D             
##D out
## End(Not run)




### * <FOOTER>
###
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
