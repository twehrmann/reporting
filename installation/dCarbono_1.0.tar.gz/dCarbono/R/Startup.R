##################################################################################################
#Startup function
#this function is executed once the library is loaded
.onAttach = function(library, pkg)
{
  Rv = R.Version()
  if(!exists("getRversion", baseenv()) || (getRversion() < "3.1.1"))
    stop("This package requires R 3.1.1 or later")
  assign(".dCarbono.home", file.path(library, pkg),
         pos=match("package:dCarbono", search()))
  dCarbono.version = "1.0 (2014-11-14), build 1"
  assign(".dCarbono.version", dCarbono.version, pos=match("package:dCarbono", search()))
  if(interactive())
  {
    packageStartupMessage(paste("Package 'dCarbono', ", dCarbono.version, ". ",sep=""),appendLF=TRUE)
    packageStartupMessage("Type 'help(dCarbono)' for summary information",appendLF=TRUE)
  }
  invisible()
}
