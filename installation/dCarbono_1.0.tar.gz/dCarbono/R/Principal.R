myfun_Sum <- function(x){c(Sum=sum(x[!is.na(x)]))}
myfun_yi <- function(x){c(yi=sum(x[!is.na(x)]))}

Cambios=function(y_t1, y_t2, t1, t2, conglomerado, estrato, ai, AreasEstratos)
{

    BaseT1T2<-data.frame(FechaT1=t1,FechaT2=t2,folio.x=conglomerado,
                        EstTrnsT1T2=estrato,CarbAerVivT1=y_t1,CarbAerVivT2=y_t2,ai=ai)
    
	#*****************************************************************************************************************#
	#####################################A)CAMBIOS DE CARBONO CON ESTIMADORES DE RAZÓN#################################

	##################################Se identifica el tiempo entre remediciones "T1-T2"###############################
	#Se crea la variable decimal de fecha en t1
	BaseT1T2$FechaDecimalT1<-(as.numeric(substr(x = BaseT1T2$FechaT1, start = 1, stop = 2))+
    			              as.numeric(substr(x = BaseT1T2$FechaT1, start = 4, stop = 5))*30)/365+
                			  as.numeric(substr(x = BaseT1T2$FechaT1, start = 7, stop = 10))
	
	BaseT1T2$FechaDecimalT2<-(as.numeric(substr(x = BaseT1T2$FechaT2, start = 1, stop = 2))+
                			  as.numeric(substr(x = BaseT1T2$FechaT2, start = 4, stop = 5))*30)/365+
                			  as.numeric(substr(x = BaseT1T2$FechaT2, start = 7, stop = 10))
	
	BaseT1T2$DifTiempoT2T1p<-(BaseT1T2$FechaDecimalT2-BaseT1T2$FechaDecimalT1)

	#Se imputa una diferencia de medicón de 5 años en las UMP de "Monitoreo"
	BaseT1T2$NA_FechaDecimalT1<-ifelse(is.na(BaseT1T2$DifTiempoT2T1), 1,0)
	BaseT1T2$DifTiempoT2T1<-ifelse(BaseT1T2$NA_FechaDecimalT1==1,5,BaseT1T2$DifTiempoT2T1p)

	###################################Se crea la variable de "Estrato-Conglomerado"###################################
	BaseT1T2$EstTrnsCong<-paste(as.character(BaseT1T2$EstTrnsT1T2),"*",as.character(BaseT1T2$folio.x))

	######################Se crea la variable de "Cambio de carbono anualizado" a nivel de sitio#######################
	BaseT1T2$CCanualizado<-(BaseT1T2$CarbAerVivT2-BaseT1T2$CarbAerVivT1)/BaseT1T2$DifTiempoT2T1
	BaseT1T2$yi<-BaseT1T2$CCanualizado

	###Se agrega la base "BaseT1T2" a nivel de parcela utilizando la vairable "EstCong" como criterio de agregación###
	#Se crea una nueva variable para contar el número de sitios con conglomerado
	BaseT1T2$contador<-1

	#Suma de NumTotParcelas, yi, ai

	BaseCongT2T1<<-0
	BaseCongT2T1<<-summaryBy(contador + yi + ai ~ EstTrnsCong,data=BaseT1T2,FUN=myfun_Sum,keep.names=TRUE, var.names=c("NumSitios","yi","ai"))


	############################Se crean las variables para obtener los estimadores de razón###########################
	#Se identifica el estrato al que pertenece cada conglomerado
	BaseCongT2T1$Estrato<-substr(x = BaseCongT2T1$EstTrnsCong, start = 1, 
								stop =as.integer(gregexpr("-",BaseCongT2T1$EstTrnsCong))-2)

	#Se crean las variables (a nivel de conglomerado) para obtener la varianza del estimador de razón por ha#
	BaseCongT2T1$yi2 <-(BaseCongT2T1$yi)^2
	BaseCongT2T1$yiai<-(BaseCongT2T1$yi*BaseCongT2T1$ai)
	BaseCongT2T1$ai2 <-(BaseCongT2T1$ai)^2

	###############################################################################
	###################Se agrega la base a nivel de Estrato########################

	###Tabla con el número parcelas por "Estrato-Conglomerado"
	#Se crea una variable para cuantificar el "número parcelas por Estrato-Conglomerado"
	BaseCongT2T1$contadorCong<-1

	#Tabla con suma total de biomasa por "Estrato"
	
	BaseEstrato<<-0
	BaseEstrato<<-summaryBy(NumSitios+ contadorCong + yi + ai + 
						   yi2 + yiai + ai2 ~ Estrato, data=BaseCongT2T1,
						   FUN=myfun_yi,keep.names=TRUE, var.names=c("NumSitios","NumCong","yi","ai","yi2","yiai","ai2"))

	AreasEstratosPerm<-0
	AreasEstratosPerm<-data.frame(Estrato=AreasEstratos$Estrato,AreaHa=AreasEstratos$AreaHa)
	
	#Se unen las bases "BaseEstrato" y "AreasEstratosPerm"
	BaseEstrato<- merge(BaseEstrato, AreasEstratosPerm, by.x = "Estrato", by.y = "Estrato",all=FALSE)

	###############################################################################
	###Se obtienen los estimadores de razón, sus varianzas e incertidumbres
	#Obtención de los ER
	BaseEstrato$ER<-BaseEstrato$yi/BaseEstrato$ai
	#Se obtiene el área promedio muestreada a nivel de conglomerado
	BaseEstrato$Prom_ai<-(BaseEstrato$ai/BaseEstrato$NumCong)

	#Se obtiene la DESVIACIÓN STÁNDAR del estimador de Razón
	#Se estima f para cada estrato
	BaseEstrato$f<-0
	BaseEstrato$f<-BaseEstrato$NumCong/BaseEstrato$AreaHa
	#Se obtienen las DS
	BaseEstrato$SdER<-sqrt(((1-BaseEstrato$f)/(BaseEstrato$NumCong*(BaseEstrato$NumCong-1)*BaseEstrato$Prom_ai^2))*
				(BaseEstrato$yi2-2*BaseEstrato$ER*BaseEstrato$yiai+BaseEstrato$ai2*
				(BaseEstrato$ER)^2))
	
	#Se obtiene la INCERTIDUMBRE del estimador de Razón
	BaseEstrato$U<-((1.96*BaseEstrato$SdER)/BaseEstrato$ER)*100
	
	return(BaseEstrato)
}