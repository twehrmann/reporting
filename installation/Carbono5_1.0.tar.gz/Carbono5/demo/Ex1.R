#rm(list=ls())
library(Carbono5)

###############################################################################
##############################Se leen las bases################################

BaseT1<-read.csv(system.file("extdata/Calculo_20140421_CarbonoSitio(2004-2012)_VERSION_19_raices_CASO1y2_TOTALESt1.csv",
                 package="Carbono5"),header=TRUE)

EstratoCong<-read.csv(system.file("extdata/EstratosCongPMNgusSerieIV_2.csv",package="Carbono5"),header=TRUE)

EstratosIPCC<-read.csv(system.file("extdata/EstratsPMN_IPCC.csv",package="Carbono5"),header=TRUE)

AreasEstratos<-read.csv(system.file("extdata/AreasEstratos.csv",package="Carbono5"),header=TRUE)


#Se crea una variable de "Conglomerado - Sitio" en las bases "BaseT1" y "EstratoCong"
BaseT1$CongSitio<-paste(BaseT1$folio,"-",BaseT1$sitio)
EstratoCong$CongSitio<-paste(EstratoCong$NUMNAL,"-",EstratoCong$Sitio)

#Se identifica el tipo de estrato PMN por conglomerado
BaseT1<- merge(BaseT1, EstratoCong, by.x = "CongSitio", by.y = "CongSitio",all=TRUE)
#Se identifica el tipo de estrato IPCC por conglomerado
BaseT1<- merge(BaseT1, EstratosIPCC, by.x = "clave_pmn4", by.y = "pf_redd_clave_subcat_leno_pri_sec",all=TRUE)


###############################################################################
####Se filtran los estratos que no pertenencen a las categor�as de "Tierras"###
######################## Forestales" o "Praderas" del IPCC#####################
BaseT1=BaseT1[BaseT1$pf_redd_ipcc_2003=="Tierras Forestales" | BaseT1$pf_redd_ipcc_2003=="Praderas",]
length(BaseT1$folio)

#se filtra todas las USM cuya "tipificaci�n" es "Inicial", "Reemplazo" o "Monitoreo"
BaseT1=BaseT1[BaseT1$tipificacion=="Inicial" |
              BaseT1$tipificacion=="Reemplazo" |
              BaseT1$tipificacion=="Monitoreo",]
length(BaseT1$folio)

#Se imputan los 0 en los conglomerdos reportados "Monitoreo" y que ten�an "Pradera"
BaseT1$CarbArboles<-ifelse(BaseT1$tipificacion=="Monitoreo" & BaseT1$pf_redd_ipcc_2003=="Praderas",0,
       as.numeric(as.character(BaseT1$carbono_arboles)))

#Se filtran todos los "NA" de la variable "CarbAerViv"
BaseT1<-BaseT1[!(is.na(BaseT1$CarbArboles)),]


#*****************************************************************************#
#A)CARBONO DE �RBOLES##########################################################

###############################################################################
#####Se crean variables auxiliares para obtener el estimador de Razon por ha###
yi<-BaseT1$CarbArboles

###Note que los �rboles mayores a 7.5 cm s�lo se midieron en parcelas###
#####de 400m2, por lo que el �rea de cada uno de estos sitios es de 0.04has####
ai <- rep(0.04,length(yi))

#Estrato
Estrato<-BaseT1$clave_pmn4

#Conglomerado
Conglomerado<-BaseT1$folio

AreasEstratos<-data.frame(Estrato=AreasEstratos$cves,AreaHa=AreasEstratos$cves4_pmn)

resultados<-ER(yi=yi,ai=ai,Estrato=Estrato,Conglomerado=Conglomerado,AreasEstratos=AreasEstratos)

resultados

