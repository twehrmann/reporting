myfunCong <- function(x)
{
	c(yi=sum(x[!is.na(x)]))
}

myfun_yi <- function(x)
{
	c(yi=sum(x[!is.na(x)]))
}


#Función para obtener los estimadores de razón y las incertidumbres
#Argumentos:
#yi: variable respuesta
#ai: Area
#Estrato
#Conglomerado
#AreasEstatos: data.frame

ER=function(yi, ai,Estrato, Conglomerado, AreasEstratos)
{

	n=length(yi)

	#Se crea un contador de sitios
	contadorSitios =rep(1,n)


	#Se crea una variable nueva de "Conglomerado-Estrato"
	EstCong<-paste(as.character(Estrato),"-",as.character(Conglomerado))

	#La base se agrega la base a nivel de Parcela (Conglomerado-Estrato)

	tmp=data.frame(yi,ai,contadorSitios,EstCong)

	BaseT1cong<-summaryBy(yi+ai+contadorSitios~EstCong, data=tmp,
        	              FUN=myfunCong,keep.names=TRUE,
                	      var.names=c("yi","ai","NumSitios"))
                      
	#A la base de Carbono a nivel de conglomerado "" se identifica el estrato al que pertenece cada conglomerado
	BaseT1cong$Estrato<-substr(x = BaseT1cong$EstCong, start = 1, 
				stop =as.integer(gregexpr("-",BaseT1cong$EstCong))-2)


	###############################################################################
	###############################################################################
	#Se crean las variables (a nivel de conglomerado) para obtener la varianza del estimador de razón por ha#
	BaseT1cong$yi2 <-(BaseT1cong$yi)^2
	BaseT1cong$yiai<-(BaseT1cong$yi*BaseT1cong$ai)
	BaseT1cong$ai2 <-(BaseT1cong$ai)^2

	###############################################################################
	###################Se agrega la base a nivel de Estrato########################

	###Tabla con el número parcelas por "Estrato-Conglomerado"
	#Se crea una variable para cuantificar el "número parcelas por Estrato-Conglomerado"
	BaseT1cong$contadorCong<-1

	#Tabla con suma total de biomasa por "Estrato"

	BaseEstrato<-0



	BaseEstrato<-summaryBy(NumSitios + contadorCong + yi + ai + yi2 + yiai + ai2 ~ Estrato,
				data=BaseT1cong,FUN=myfun_yi,
			        keep.names=TRUE, 
			        var.names=c("NumSitios","NumCong","yi","ai","yi2","yiai","ai2"))


	#FIXME: ESTO TAMBIEN DEBE PASARSE COMO ARGUEMENTO A LA FUNCION
	#Se identifica el área de cada estrato
	#AreasEstratos<-data.frame(Estrato=AreasEstratos$cves,AreaHa=AreasEstratos$cves4_pmn)
	BaseEstrato<- merge(BaseEstrato, AreasEstratos, by.x = "Estrato", by.y = "Estrato",all=FALSE)

	###############################################################################
	###Se obtienen los estimadores de razón, sus varianzas e incertidumbres
	#Obtención de los ER
	BaseEstrato$ER<-BaseEstrato$yi/BaseEstrato$ai

	#Se obtiene el área promedio muestreada a nivel de conglomerado
	BaseEstrato$Prom_ai<-(BaseEstrato$ai/BaseEstrato$NumCong)

	#Se obtiene la DESVIACIÓN ESTÁNDAR del estimador de Razón
	#Se estima f para cada estrato
	BaseEstrato$f<-0
	BaseEstrato$f<-BaseEstrato$NumCong/BaseEstrato$AreaHa

	#Se obtienen las DS
	BaseEstrato$SdER<-sqrt(((1-BaseEstrato$f)/(BaseEstrato$NumCong*(BaseEstrato$NumCong-1)*BaseEstrato$Prom_ai^2))*
				(BaseEstrato$yi2-2*BaseEstrato$ER*BaseEstrato$yiai+BaseEstrato$ai2*
				(BaseEstrato$ER)^2))

	#Se obtiene la INCERTIDUMBRE del estimador de Razón
	BaseEstrato$U<-((1.96*BaseEstrato$SdER)/BaseEstrato$ER)*100

	BaseEstrato

}
