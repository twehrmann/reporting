##################################################################################################
#Startup function
#this function is executed once the library is loaded
.onAttach = function(library, pkg)
{
  Rv = R.Version()
  if(!exists("getRversion", baseenv()) || (getRversion() < "3.1.1"))
    stop("This package requires R 3.1.1 or later")
  assign(".Carbono5.home", file.path(library, pkg),
         pos=match("package:Carbono5", search()))
  Carbono5.version = "1.0 (2014-11-14), build 1"
  assign(".Carbono5.version", Carbono5.version, pos=match("package:Carbono5", search()))
  if(interactive())
  {
    packageStartupMessage(paste("Package 'Carbono5', ", Carbono5.version, ". ",sep=""),appendLF=TRUE)
    packageStartupMessage("Type 'help(Carbono5)' for summary information",appendLF=TRUE)
  }
  invisible()
}
